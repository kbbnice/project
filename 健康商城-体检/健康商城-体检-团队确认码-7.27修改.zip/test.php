<?php
    $data = $_GET('params');


    echo false;
?>